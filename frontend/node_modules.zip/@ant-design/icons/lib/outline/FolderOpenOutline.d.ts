import { IconDefinition } from '../types';
declare const FolderOpenOutline: IconDefinition;
export default FolderOpenOutline;
