import { IconDefinition } from '../types';
declare const DeleteOutline: IconDefinition;
export default DeleteOutline;
