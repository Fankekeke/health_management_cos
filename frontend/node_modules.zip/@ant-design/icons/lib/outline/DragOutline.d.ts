import { IconDefinition } from '../types';
declare const DragOutline: IconDefinition;
export default DragOutline;
