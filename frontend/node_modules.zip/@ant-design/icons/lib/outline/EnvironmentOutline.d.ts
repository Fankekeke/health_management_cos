import { IconDefinition } from '../types';
declare const EnvironmentOutline: IconDefinition;
export default EnvironmentOutline;
