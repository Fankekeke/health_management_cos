import { IconDefinition } from '../types';
declare const MinusSquareOutline: IconDefinition;
export default MinusSquareOutline;
