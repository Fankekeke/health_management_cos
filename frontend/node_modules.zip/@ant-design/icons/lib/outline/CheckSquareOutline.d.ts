import { IconDefinition } from '../types';
declare const CheckSquareOutline: IconDefinition;
export default CheckSquareOutline;
