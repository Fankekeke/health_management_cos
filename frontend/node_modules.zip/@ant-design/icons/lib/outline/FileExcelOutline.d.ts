import { IconDefinition } from '../types';
declare const FileExcelOutline: IconDefinition;
export default FileExcelOutline;
