import { IconDefinition } from '../types';
declare const CaretUpOutline: IconDefinition;
export default CaretUpOutline;
