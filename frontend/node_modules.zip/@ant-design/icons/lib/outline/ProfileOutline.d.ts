import { IconDefinition } from '../types';
declare const ProfileOutline: IconDefinition;
export default ProfileOutline;
