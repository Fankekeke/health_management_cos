import { IconDefinition } from '../types';
declare const HighlightOutline: IconDefinition;
export default HighlightOutline;
