import { IconDefinition } from '../types';
declare const BookOutline: IconDefinition;
export default BookOutline;
