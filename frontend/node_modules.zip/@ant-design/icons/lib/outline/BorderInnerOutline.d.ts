import { IconDefinition } from '../types';
declare const BorderInnerOutline: IconDefinition;
export default BorderInnerOutline;
