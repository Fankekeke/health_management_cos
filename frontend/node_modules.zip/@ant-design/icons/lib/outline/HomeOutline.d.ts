import { IconDefinition } from '../types';
declare const HomeOutline: IconDefinition;
export default HomeOutline;
