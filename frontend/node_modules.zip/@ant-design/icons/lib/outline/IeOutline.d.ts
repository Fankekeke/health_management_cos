import { IconDefinition } from '../types';
declare const IeOutline: IconDefinition;
export default IeOutline;
