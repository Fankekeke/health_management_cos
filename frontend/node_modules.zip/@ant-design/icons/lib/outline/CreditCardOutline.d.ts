import { IconDefinition } from '../types';
declare const CreditCardOutline: IconDefinition;
export default CreditCardOutline;
