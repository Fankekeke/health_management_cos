import { IconDefinition } from '../types';
declare const CheckCircleOutline: IconDefinition;
export default CheckCircleOutline;
