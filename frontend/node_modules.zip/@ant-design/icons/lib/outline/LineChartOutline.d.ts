import { IconDefinition } from '../types';
declare const LineChartOutline: IconDefinition;
export default LineChartOutline;
