import { IconDefinition } from '../types';
declare const ExclamationCircleOutline: IconDefinition;
export default ExclamationCircleOutline;
