import { IconDefinition } from '../types';
declare const PropertySafetyOutline: IconDefinition;
export default PropertySafetyOutline;
