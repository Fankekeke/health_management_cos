import { IconDefinition } from '../types';
declare const MoreOutline: IconDefinition;
export default MoreOutline;
