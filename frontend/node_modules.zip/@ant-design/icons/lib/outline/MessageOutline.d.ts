import { IconDefinition } from '../types';
declare const MessageOutline: IconDefinition;
export default MessageOutline;
