import { IconDefinition } from '../types';
declare const GithubOutline: IconDefinition;
export default GithubOutline;
