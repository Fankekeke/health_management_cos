import { IconDefinition } from '../types';
declare const DoubleLeftOutline: IconDefinition;
export default DoubleLeftOutline;
