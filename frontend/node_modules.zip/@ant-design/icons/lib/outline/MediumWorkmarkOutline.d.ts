import { IconDefinition } from '../types';
declare const MediumWorkmarkOutline: IconDefinition;
export default MediumWorkmarkOutline;
