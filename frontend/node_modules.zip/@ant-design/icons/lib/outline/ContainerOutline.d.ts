import { IconDefinition } from '../types';
declare const ContainerOutline: IconDefinition;
export default ContainerOutline;
