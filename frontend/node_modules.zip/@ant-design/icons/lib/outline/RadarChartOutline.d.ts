import { IconDefinition } from '../types';
declare const RadarChartOutline: IconDefinition;
export default RadarChartOutline;
