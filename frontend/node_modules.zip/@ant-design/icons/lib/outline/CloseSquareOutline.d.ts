import { IconDefinition } from '../types';
declare const CloseSquareOutline: IconDefinition;
export default CloseSquareOutline;
