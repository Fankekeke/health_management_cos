import { IconDefinition } from '../types';
declare const DatabaseOutline: IconDefinition;
export default DatabaseOutline;
