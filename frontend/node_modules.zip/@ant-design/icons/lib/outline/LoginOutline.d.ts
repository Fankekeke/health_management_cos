import { IconDefinition } from '../types';
declare const LoginOutline: IconDefinition;
export default LoginOutline;
