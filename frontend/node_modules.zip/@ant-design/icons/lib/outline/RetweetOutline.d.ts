import { IconDefinition } from '../types';
declare const RetweetOutline: IconDefinition;
export default RetweetOutline;
