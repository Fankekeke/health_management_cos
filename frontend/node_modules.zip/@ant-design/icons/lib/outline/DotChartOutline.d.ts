import { IconDefinition } from '../types';
declare const DotChartOutline: IconDefinition;
export default DotChartOutline;
