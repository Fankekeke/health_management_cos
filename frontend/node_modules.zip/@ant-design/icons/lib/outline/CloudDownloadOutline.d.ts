import { IconDefinition } from '../types';
declare const CloudDownloadOutline: IconDefinition;
export default CloudDownloadOutline;
