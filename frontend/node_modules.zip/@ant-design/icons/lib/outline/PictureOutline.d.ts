import { IconDefinition } from '../types';
declare const PictureOutline: IconDefinition;
export default PictureOutline;
