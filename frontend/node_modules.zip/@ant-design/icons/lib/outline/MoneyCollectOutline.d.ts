import { IconDefinition } from '../types';
declare const MoneyCollectOutline: IconDefinition;
export default MoneyCollectOutline;
