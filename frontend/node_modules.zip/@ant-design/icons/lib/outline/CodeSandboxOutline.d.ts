import { IconDefinition } from '../types';
declare const CodeSandboxOutline: IconDefinition;
export default CodeSandboxOutline;
