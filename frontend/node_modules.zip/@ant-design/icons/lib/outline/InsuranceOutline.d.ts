import { IconDefinition } from '../types';
declare const InsuranceOutline: IconDefinition;
export default InsuranceOutline;
