import { IconDefinition } from '../types';
declare const CaretDownFill: IconDefinition;
export default CaretDownFill;
