import { IconDefinition } from '../types';
declare const FilePdfFill: IconDefinition;
export default FilePdfFill;
