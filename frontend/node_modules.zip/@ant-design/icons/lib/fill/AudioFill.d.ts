import { IconDefinition } from '../types';
declare const AudioFill: IconDefinition;
export default AudioFill;
