import { IconDefinition } from '../types';
declare const TagFill: IconDefinition;
export default TagFill;
