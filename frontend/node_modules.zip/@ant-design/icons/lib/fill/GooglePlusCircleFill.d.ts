import { IconDefinition } from '../types';
declare const GooglePlusCircleFill: IconDefinition;
export default GooglePlusCircleFill;
