import { IconDefinition } from '../types';
declare const ForwardFill: IconDefinition;
export default ForwardFill;
