import { IconDefinition } from '../types';
declare const PrinterFill: IconDefinition;
export default PrinterFill;
