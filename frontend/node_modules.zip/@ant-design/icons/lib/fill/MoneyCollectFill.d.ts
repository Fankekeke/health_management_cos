import { IconDefinition } from '../types';
declare const MoneyCollectFill: IconDefinition;
export default MoneyCollectFill;
