import { IconDefinition } from '../types';
declare const SecurityScanFill: IconDefinition;
export default SecurityScanFill;
