import { IconDefinition } from '../types';
declare const DownSquareFill: IconDefinition;
export default DownSquareFill;
