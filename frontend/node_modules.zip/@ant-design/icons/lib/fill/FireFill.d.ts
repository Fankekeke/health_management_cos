import { IconDefinition } from '../types';
declare const FireFill: IconDefinition;
export default FireFill;
