import { IconDefinition } from '../types';
declare const SafetyCertificateFill: IconDefinition;
export default SafetyCertificateFill;
