import { IconDefinition } from '../types';
declare const LeftCircleFill: IconDefinition;
export default LeftCircleFill;
