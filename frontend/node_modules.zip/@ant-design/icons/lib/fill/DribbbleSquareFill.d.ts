import { IconDefinition } from '../types';
declare const DribbbleSquareFill: IconDefinition;
export default DribbbleSquareFill;
