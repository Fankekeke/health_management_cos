import { IconDefinition } from '../types';
declare const DropboxCircleFill: IconDefinition;
export default DropboxCircleFill;
