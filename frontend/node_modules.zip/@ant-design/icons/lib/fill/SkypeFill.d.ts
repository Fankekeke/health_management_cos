import { IconDefinition } from '../types';
declare const SkypeFill: IconDefinition;
export default SkypeFill;
