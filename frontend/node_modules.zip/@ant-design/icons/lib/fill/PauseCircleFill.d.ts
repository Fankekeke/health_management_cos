import { IconDefinition } from '../types';
declare const PauseCircleFill: IconDefinition;
export default PauseCircleFill;
