import { IconDefinition } from '../types';
declare const IdcardFill: IconDefinition;
export default IdcardFill;
