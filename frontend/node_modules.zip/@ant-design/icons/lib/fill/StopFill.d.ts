import { IconDefinition } from '../types';
declare const StopFill: IconDefinition;
export default StopFill;
