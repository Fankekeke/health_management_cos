import { IconDefinition } from '../types';
declare const FundFill: IconDefinition;
export default FundFill;
