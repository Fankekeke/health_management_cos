import { IconDefinition } from '../types';
declare const DatabaseFill: IconDefinition;
export default DatabaseFill;
