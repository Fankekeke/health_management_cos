import { IconDefinition } from '../types';
declare const FileMarkdownFill: IconDefinition;
export default FileMarkdownFill;
