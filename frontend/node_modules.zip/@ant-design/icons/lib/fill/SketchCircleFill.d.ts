import { IconDefinition } from '../types';
declare const SketchCircleFill: IconDefinition;
export default SketchCircleFill;
