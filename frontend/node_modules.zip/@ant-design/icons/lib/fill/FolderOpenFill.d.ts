import { IconDefinition } from '../types';
declare const FolderOpenFill: IconDefinition;
export default FolderOpenFill;
