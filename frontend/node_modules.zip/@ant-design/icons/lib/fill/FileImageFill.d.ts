import { IconDefinition } from '../types';
declare const FileImageFill: IconDefinition;
export default FileImageFill;
