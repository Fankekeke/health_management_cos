import { IconDefinition } from '../types';
declare const CloseSquareFill: IconDefinition;
export default CloseSquareFill;
