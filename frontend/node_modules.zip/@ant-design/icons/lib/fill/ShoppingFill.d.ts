import { IconDefinition } from '../types';
declare const ShoppingFill: IconDefinition;
export default ShoppingFill;
