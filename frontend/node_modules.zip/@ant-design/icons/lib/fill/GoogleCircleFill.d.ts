import { IconDefinition } from '../types';
declare const GoogleCircleFill: IconDefinition;
export default GoogleCircleFill;
