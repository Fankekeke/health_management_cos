import { IconDefinition } from '../types';
declare const MailFill: IconDefinition;
export default MailFill;
