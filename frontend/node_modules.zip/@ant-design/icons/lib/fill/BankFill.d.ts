import { IconDefinition } from '../types';
declare const BankFill: IconDefinition;
export default BankFill;
