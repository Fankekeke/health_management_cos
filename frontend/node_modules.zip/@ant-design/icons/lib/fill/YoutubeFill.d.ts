import { IconDefinition } from '../types';
declare const YoutubeFill: IconDefinition;
export default YoutubeFill;
