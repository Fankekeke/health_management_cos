import { IconDefinition } from '../types';
declare const RedEnvelopeFill: IconDefinition;
export default RedEnvelopeFill;
