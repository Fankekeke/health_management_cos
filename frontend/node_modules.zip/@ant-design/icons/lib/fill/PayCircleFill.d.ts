import { IconDefinition } from '../types';
declare const PayCircleFill: IconDefinition;
export default PayCircleFill;
