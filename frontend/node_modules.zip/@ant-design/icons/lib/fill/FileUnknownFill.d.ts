import { IconDefinition } from '../types';
declare const FileUnknownFill: IconDefinition;
export default FileUnknownFill;
